# Oversight Model

- Human councils define constraints
- AI executes within bounds
- Continuous auditing
- Kill‑switch preserved
