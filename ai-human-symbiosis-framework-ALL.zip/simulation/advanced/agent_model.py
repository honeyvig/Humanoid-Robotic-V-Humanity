class Agent:
    def __init__(self, role):
        self.role = role

class HumanAgent(Agent):
    def decide_values(self):
        return ["dignity", "beauty", "continuity"]

class AIAgent(Agent):
    def optimize(self, constraints):
        return "planetary systems stabilized"
