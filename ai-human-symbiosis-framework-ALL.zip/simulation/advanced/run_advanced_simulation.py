from agent_model import HumanAgent, AIAgent
from planetary_model import PlanetarySystem

human = HumanAgent("human")
ai = AIAgent("ai")
planet = PlanetarySystem()

values = human.decide_values()
result = ai.optimize(values)
planet.repair()

print(result, planet.health)
