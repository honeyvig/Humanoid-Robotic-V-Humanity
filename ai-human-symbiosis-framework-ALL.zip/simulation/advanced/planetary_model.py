class PlanetarySystem:
    def __init__(self):
        self.health = 50

    def repair(self):
        self.health += 10
