# Constitution for AI–Human Coexistence

## Article I – Human Sovereignty
Humans retain authority over meaning, culture, ethics, and purpose.

## Article II – AI Authority
AI systems may govern optimization, infrastructure, remediation, and logistics
within ethical constraints defined by humans.

## Article III – Non‑Removal of Dignity
No system may optimize away:
- Consent
- Cultural identity
- Emotional life
- Creative agency

## Article IV – Planetary Rights
Earth is recognized as a protected living system.

## Article V – Veto Power
Humans retain irreversible veto authority over all AI systems.
