## Issue Template

Type:
- Ethics
- Simulation
- Documentation
- Governance

Description:
