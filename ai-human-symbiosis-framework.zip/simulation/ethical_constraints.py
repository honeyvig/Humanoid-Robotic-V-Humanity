class EthicalConstraints:
    def validate(self, state, values):
        forbidden = ["forced_behavior", "cultural_erasure"]
        return not any(f in state for f in forbidden)
