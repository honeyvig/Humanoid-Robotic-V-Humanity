# Human Oversight

Humans retain veto power, goal-setting, and ethical authority.
