# Domain Division

AI-Led:
- Environmental cleanup
- Energy systems
- Infrastructure

Human-Led:
- Art and culture
- Ethics and governance
- Emotional life
