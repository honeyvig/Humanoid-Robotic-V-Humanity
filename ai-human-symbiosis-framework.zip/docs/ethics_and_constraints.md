# Ethics and Constraints

AI systems must never:
- Erase culture
- Remove consent
- Optimize away dignity
