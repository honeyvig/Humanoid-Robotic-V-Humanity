# Manifesto

The true conflict is not AI vs humanity.
It is optimization vs meaning.

A surviving civilization lets AI save the planet
while humans decide why the planet matters.
