# Humanoid Robotics

Speculative designs for humanoid systems operating in hazardous environments.
